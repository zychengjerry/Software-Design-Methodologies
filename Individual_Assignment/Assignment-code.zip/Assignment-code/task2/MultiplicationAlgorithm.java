/*
 * The given code is provided to assist you to complete the required tasks. But the
 * given code is often incomplete. You have to read and understand the given code
 * carefully, before you can apply the code properly.
 */


/*
 * Please review Lecture 5 Algorithms Part I, slide 49 to complete this task.
 * */

public class MultiplicationAlgorithm {

    /**
     * Using divide-and-conquer to implement the Karatsuba multiplication to compute the product x times y. 
	 * x and y are two n-digit input numbers.
     *
     * @param input x
     * @param input y
     */
    public static long KMultiply(long x, long y){
        // TODO: Complete this method
        tracker.calltracking(x,y); //Do not modify this method. Otherwise, you will be penalized for violation.
        // START YOUR CODE


        return 0;
        // END YOUR CODE
    }
}
